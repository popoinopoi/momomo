﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        //Ballが飛ぶ方向
        this.GetComponent<Rigidbody>().velocity = new Vector3(0.0f, 8.0f, 15.0f);
    }

    // Update is called once per frame
    void Update()
    {

    }
    // カメラから見えなくなったら
    void OnBecameInvisible()
    {
        // ボールを消す
        Destroy(this.gameObject);
    }
    void OnCollisionEnter(Collision collision)
    {
        //Ballが敵にぶつかったら
        if (collision.gameObject.tag == "Enemy")
        {
            Destroy(this.gameObject);
        }
        if (collision.gameObject.tag == "EnemyV")
        {
            Destroy(this.gameObject);
        }
    }
}