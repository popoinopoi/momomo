﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Launcher : MonoBehaviour
{
    // ボールのプレファブ
    public GameObject ballPrefab;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // マウス右ボタンが押されたら
        if (Input.GetMouseButtonDown(1))
        {
            // ボールを出現させる
            Instantiate(this.ballPrefab);
        }

    }
}