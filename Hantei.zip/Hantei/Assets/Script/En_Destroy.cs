﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class En_Destroy : MonoBehaviour
{
    private int d_count = 0;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Ball")
        {
            d_count++;
        }
        if (d_count == 2)
        {
            Destroy(this.gameObject);
        }
    }
}