﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {
    public int count = 0;

	// Use this for initialization
	void Start () {
        
    }

    // Update is called once per frame
    void Update () {
		
	}

    protected virtual void OnCollisionEnter(Collision collision)
    {
        //Ballに当たったら
        if (collision.gameObject.tag == "Ball")
        {
            count++;
            Chenge();
        }
    }
    protected virtual void Chenge()
    {
        if (count == 1)    //1回目　元の姿に戻る
        {
            Destroy(this.gameObject);

        }
    }
}
