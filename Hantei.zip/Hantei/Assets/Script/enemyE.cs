﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyE : EnemyController
{
    public GameObject enemyVPrefab1;
    public GameObject enemy;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    protected override void OnCollisionEnter(Collision collision)
    {
        base.OnCollisionEnter(collision);
    }
    protected override void Chenge()
    {
        if (count == 1)    //1回目　　元の姿
        {
            Vector3 e_pos = enemy.transform.position;

            Debug.Log(e_pos);
            Instantiate(this.enemyVPrefab1, e_pos, Quaternion.identity);
        }
    }
}
